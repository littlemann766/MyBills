# My Bills 20.0.134

Full-package rebuild using the supplied reference screenshot as the visual baseline. Headers are sticky/stationary and navy from the start of every tab. Cards, tab tiles, action buttons, and bottom navigation use navy with white text and cyan borders/highlights. Bottom-navigation icons are normalized to prominent line icons. Calendar cells, bills, forms, and ledger content remain light for readability.
