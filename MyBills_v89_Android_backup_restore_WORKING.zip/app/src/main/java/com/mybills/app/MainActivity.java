package com.mybills.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_CREATE_BACKUP = 4101;
    private static final int REQ_OPEN_FILE = 4102;
    private static final int REQ_NATIVE_RESTORE = 4103;

    private WebView webView;
    private String pendingBackupJson;
    private ValueCallback<Uri[]> fileChooserCallback;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try { startActivityForResult(intent, REQ_OPEN_FILE); }
                catch (Exception e) {
                    fileChooserCallback = null;
                    Toast.makeText(MainActivity.this, "Unable to open the file picker.", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }
        });
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface public void saveBackup(String json) {
            pendingBackupJson = json;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "my-bills-backup-v89.json");
                try { startActivityForResult(intent, REQ_CREATE_BACKUP); }
                catch (Exception e) {
                    pendingBackupJson = null;
                    Toast.makeText(MainActivity.this, "Unable to open the save picker.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public void restoreBackup() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                // */* is intentional: some Android file managers label .json as text/plain
                // or application/octet-stream and otherwise hide valid My Bills backups.
                intent.setType("*/*");
                try { startActivityForResult(intent, REQ_NATIVE_RESTORE); }
                catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Unable to open the restore picker.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public void requestNotificationPermission() { }
        @JavascriptInterface public void scheduleNotifications(String payload) { }
        @JavascriptInterface public void testNotification(String payload) { }
    }

    private String readText(Uri uri) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (InputStream in = getContentResolver().openInputStream(uri);
             BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            char[] buf = new char[8192];
            int n;
            while ((n = reader.read(buf)) != -1) sb.append(buf, 0, n);
        }
        return sb.toString();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_CREATE_BACKUP) {
            String json = pendingBackupJson;
            pendingBackupJson = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null && json != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    if (out == null) throw new Exception("No output stream");
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                    Toast.makeText(this, "Backup saved successfully.", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Backup could not be saved.", Toast.LENGTH_LONG).show();
                }
            }
            return;
        }

        if (requestCode == REQ_NATIVE_RESTORE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try {
                    String json = readText(data.getData());
                    String quoted = JSONObject.quote(json);
                    webView.evaluateJavascript("window.restoreBackupTextV89(" + quoted + ");", null);
                } catch (Exception e) {
                    Toast.makeText(this, "Backup could not be read.", Toast.LENGTH_LONG).show();
                }
            }
            return;
        }

        if (requestCode == REQ_OPEN_FILE && fileChooserCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            fileChooserCallback.onReceiveValue(result);
            fileChooserCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (fileChooserCallback != null) {
            fileChooserCallback.onReceiveValue(null);
            fileChooserCallback = null;
        }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
